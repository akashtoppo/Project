package com.akash;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Inet4Address;
import java.util.Date;





public class Logger {
	
	private String path;
	
	private Logger() {
		path ="log.txt";
	}
	private static Logger obj = null;
	
	public static synchronized Logger getInstance() {
		
		if(obj == null)
			obj =new Logger();
		return obj;
	}
	
	public void log(String data) throws IOException
	{
		BufferedWriter bw = null;
		try
		{
			bw = new BufferedWriter(new FileWriter(path,true));
			
			Date dt = new Date();
		//	String browserDetails = (String)request.getHeader("User-Agent");
			bw.write("IP Address = "+Inet4Address.getLocalHost().getHostAddress()+dt+data);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(bw!=null)
				bw.close();
		}
	}

}
