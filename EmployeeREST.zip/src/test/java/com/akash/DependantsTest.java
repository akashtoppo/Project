package com.akash;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DependantsTest {

	@Test
	void testGetFirstName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetFirstName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetLastName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetLastName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetGender() {
		fail("Not yet implemented");
	}

	@Test
	void testSetGender() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDOB() {
		fail("Not yet implemented");
	}

	@Test
	void testSetDOB() {
		fail("Not yet implemented");
	}

	@Test
	void testGetRelationship() {
		fail("Not yet implemented");
	}

	@Test
	void testSetRelationship() {
		fail("Not yet implemented");
	}

}
