package com.akash;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EducationalQualificationTest {

	@Test
	void testGetType() {
		fail("Not yet implemented");
	}

	@Test
	void testSetType() {
		fail("Not yet implemented");
	}

	@Test
	void testGetStartDate() {
		fail("Not yet implemented");
	}

	@Test
	void testSetStartDate() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEndDate() {
		fail("Not yet implemented");
	}

	@Test
	void testSetEndDate() {
		fail("Not yet implemented");
	}

	@Test
	void testGetInstitution() {
		fail("Not yet implemented");
	}

	@Test
	void testSetInstitution() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAddress() {
		fail("Not yet implemented");
	}

	@Test
	void testSetAddress() {
		fail("Not yet implemented");
	}

	@Test
	void testGetPercentage() {
		fail("Not yet implemented");
	}

	@Test
	void testSetPercentage() {
		fail("Not yet implemented");
	}

}
