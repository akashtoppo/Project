package com.akash;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Employee {

	@Id
	@GeneratedValue
	private Integer id;
	private String FirstName;
	private String LastName;
	private Date DOB;
	private String Gender;
	private String BloodGroup;
	private String Address;
	
	private Integer EmployementId;
	private Date StartDate;
	private Date EndDate;
	private String Designation;
	private String Department;
	private String Status;
	private String ReportingManager;
	
	@Embedded
	//@OneToOne(cascade=CascadeType.ALL)
	private Dependants dependants;
	
	@Embedded
	//@OneToOne(cascade=CascadeType.ALL)
	private EducationalQualification eq;


	public Dependants getDependants() {
		return dependants;
	}

	public void setDependants(Dependants dependants) {
		
		
		this.dependants = dependants;
	}


	public EducationalQualification getEq() {
		return eq;
	}

	public void setEq(EducationalQualification eq) {
		this.eq = eq;
	}

	public Employee() {

	}

	

	
	public Employee(Integer id, String firstName, String lastName, Date dOB, String gender, String bloodGroup,
			String address, Integer employementId, Date startDate, Date endDate, String designation, String department,
			String status, String reportingManager, Dependants dependants, EducationalQualification eq) {
		super();
		this.id = id;
		
		 if(firstName==null || firstName.trim().equals(""))
				throw new IllegalArgumentException("First Name name cannot be null or blank");
		FirstName = firstName;
		
		 if(lastName==null || lastName.trim().equals(""))
				throw new IllegalArgumentException("Last Name cannot be null or blank");
	    LastName = lastName;
	    
	    if((dOB instanceof Date)==false)
			throw new IllegalArgumentException("Enter YYYY-MM-DD ");
	    DOB = dOB;
		
		if(gender==null || gender.trim().equals(""))
				throw new IllegalArgumentException("Gender cannot be null or blank");
		Gender = gender;
		
		 if(bloodGroup==null || bloodGroup.trim().equals(""))
				throw new IllegalArgumentException("Blood Group cannot be null or blank");
		BloodGroup = bloodGroup;
		
		 if(address==null || address.trim().equals(""))
				throw new IllegalArgumentException("Address cannot be null or blank");
		Address = address;
		
		 if(employementId==null )
				throw new IllegalArgumentException("employementId cannot be null");
		
		EmployementId = employementId;
		
		 if((startDate instanceof Date)==false)
				throw new IllegalArgumentException("Enter YYYY-MM-DD ");
		
		StartDate = startDate;
		
		 if((endDate instanceof Date)==false)
				throw new IllegalArgumentException("Enter YYYY-MM-DD ");
		EndDate = endDate;
		
		 if(designation==null || designation.trim().equals(""))
				throw new IllegalArgumentException("Desigination cannot be null or blank");
		Designation = designation;
		
		 if(department==null || department.trim().equals(""))
				throw new IllegalArgumentException("Department name cannot be null or blank");
		Department = department;
		
		if(status==null || status.trim().equals(""))
				throw new IllegalArgumentException("status cannot be null or blank");
		Status = status;
		
		if(reportingManager==null || reportingManager.trim().equals(""))
				throw new IllegalArgumentException("Reporting Manager name cannot be null or blank");
		ReportingManager = reportingManager;
		
		this.dependants = dependants;
		this.eq = eq;
	}

	public Integer getId() {
		return id;
	}


	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		
		
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getBloodGroup() {
		return BloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		BloodGroup = bloodGroup;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public Integer getEmployementId() {
		return EmployementId;
	}

	public void setEmployementId(Integer employementId) {
		EmployementId = employementId;
	}

	public Date getStartDate() {
		return StartDate;
	}

	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}

	public Date getEndDate() {
		return EndDate;
	}

	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String department) {
		Department = department;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getReportingManager() {
		return ReportingManager;
	}

	public void setReportingManager(String reportingManager) {
		ReportingManager = reportingManager;
	}

}
