package com.akash;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EmployeeTest {

	@Test
	void testGetDependants() {
		fail("Not yet implemented");
	}

	@Test
	void testSetDependants() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEq() {
		fail("Not yet implemented");
	}

	@Test
	void testSetEq() {
		fail("Not yet implemented");
	}

	@Test
	void testEmployee() {
		fail("Not yet implemented");
	}

	@Test
	void testEmployeeIntegerStringStringDateStringStringStringIntegerDateDateStringStringStringStringDependantsEducationalQualification() {
		fail("Not yet implemented");
	}

	@Test
	void testGetId() {
		fail("Not yet implemented");
	}

	@Test
	void testGetFirstName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetFirstName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetLastName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetLastName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDOB() {
		fail("Not yet implemented");
	}

	@Test
	void testSetDOB() {
		fail("Not yet implemented");
	}

	@Test
	void testGetGender() {
		fail("Not yet implemented");
	}

	@Test
	void testSetGender() {
		fail("Not yet implemented");
	}

	@Test
	void testGetBloodGroup() {
		fail("Not yet implemented");
	}

	@Test
	void testSetBloodGroup() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAddress() {
		fail("Not yet implemented");
	}

	@Test
	void testSetAddress() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEmployementId() {
		fail("Not yet implemented");
	}

	@Test
	void testSetEmployementId() {
		fail("Not yet implemented");
	}

	@Test
	void testGetStartDate() {
		fail("Not yet implemented");
	}

	@Test
	void testSetStartDate() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEndDate() {
		fail("Not yet implemented");
	}

	@Test
	void testSetEndDate() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDesignation() {
		fail("Not yet implemented");
	}

	@Test
	void testSetDesignation() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDepartment() {
		fail("Not yet implemented");
	}

	@Test
	void testSetDepartment() {
		fail("Not yet implemented");
	}

	@Test
	void testGetStatus() {
		fail("Not yet implemented");
	}

	@Test
	void testSetStatus() {
		fail("Not yet implemented");
	}

	@Test
	void testGetReportingManager() {
		fail("Not yet implemented");
	}

	@Test
	void testSetReportingManager() {
		fail("Not yet implemented");
	}

}
