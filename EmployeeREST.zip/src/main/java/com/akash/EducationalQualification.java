package com.akash;

import java.util.Date;

import javax.persistence.Embeddable;

@Embeddable
public class EducationalQualification {

	private String Type;
	private Date StartDate;
	private Date EndDate;
	private String Institution;
	private String Address;
	private Float Percentage;

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public Date getStartDate() {
		return StartDate;
	}

	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}

	public Date getEndDate() {
		return EndDate;
	}

	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}

	public String getInstitution() {
		return Institution;
	}

	public void setInstitution(String institution) {
		Institution = institution;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public Float getPercentage() {
		return Percentage;
	}

	public void setPercentage(Float percentage) {
		Percentage = percentage;
	}

}
